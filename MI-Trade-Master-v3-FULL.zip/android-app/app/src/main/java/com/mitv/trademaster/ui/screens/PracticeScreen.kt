package com.mitv.trademaster.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mitv.trademaster.ui.theme.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private data class DemoCandle(val open: Float, val close: Float, val high: Float, val low: Float) {
    val isBullish get() = close >= open
    val bodySize get() = kotlin.math.abs(close - open)
}

private enum class GameState { SETUP, PLAYING, FINISHED }

@Composable
fun PracticeScreen(language: String) {
    var gameState by remember { mutableStateOf(GameState.SETUP) }
    var startingBalance by remember { mutableStateOf(50f) }
    var tradeAmount by remember { mutableStateOf(10f) }
    var targetBalance by remember { mutableStateOf(100f) }

    var balance by remember { mutableStateOf(50f) }
    var candles by remember { mutableStateOf(generateInitialCandles()) }
    var wins by remember { mutableStateOf(0) }
    var losses by remember { mutableStateOf(0) }
    var lastExplanation by remember { mutableStateOf<String?>(null) }
    var awaitingReveal by remember { mutableStateOf(false) }
    var pendingGuess by remember { mutableStateOf<Boolean?>(null) }

    if (gameState == GameState.SETUP) {
        SetupScreen(
            language = language,
            startingBalance = startingBalance,
            onStartingBalanceChange = { startingBalance = it },
            tradeAmount = tradeAmount,
            onTradeAmountChange = { tradeAmount = it },
            targetBalance = targetBalance,
            onTargetBalanceChange = { targetBalance = it },
            onStart = {
                balance = startingBalance
                candles = generateInitialCandles()
                wins = 0; losses = 0; lastExplanation = null
                gameState = GameState.PLAYING
            }
        )
        return
    }

    if (gameState == GameState.FINISHED) {
        ResultScreen(
            language = language,
            won = balance >= targetBalance,
            finalBalance = balance,
            wins = wins,
            losses = losses,
            onRestart = { gameState = GameState.SETUP }
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize().background(BgBlack).padding(20.dp)) {
        Row(horizontalAlignment = Alignment.CenterHorizontally, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text(if (language == "ur") "پریکٹس موڈ" else "Practice Mode", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (language == "ur") "ڈیمو بیلنس — کوئی اصل رقم نہیں" else "DEMO balance — no real money", color = BrandSilverDim, fontSize = 11.sp)
            }
            TextButton(onClick = { gameState = GameState.SETUP }) {
                Text(if (language == "ur") "دوبارہ ترتیب" else "Reset", color = BrandGreen, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(colors = CardDefaults.cardColors(containerColor = PanelDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(if (language == "ur") "ڈیمو بیلنس" else "Demo Balance", color = BrandSilverDim, fontSize = 10.sp)
                        Text("$${"%.2f".format(balance)}", color = if (balance >= startingBalance) BrandGreen else BrandRed, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (language == "ur") "ہدف" else "Target", color = BrandSilverDim, fontSize = 10.sp)
                        Text("$${"%.0f".format(targetBalance)}", color = BrandSilver, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                val progress = (balance / targetBalance).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    color = BrandGreen, trackColor = LineSubtle,
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ScoreCard(modifier = Modifier.weight(1f), label = if (language == "ur") "جیت" else "Wins", value = wins.toString(), color = BrandGreen)
            ScoreCard(modifier = Modifier.weight(1f), label = if (language == "ur") "ہار" else "Losses", value = losses.toString(), color = BrandRed)
            ScoreCard(modifier = Modifier.weight(1f), label = if (language == "ur") "فی ٹریڈ" else "Per Trade", value = "$${tradeAmount.toInt()}", color = BrandSilver)
        }

        Spacer(Modifier.height(14.dp))

        Box(modifier = Modifier.fillMaxWidth().height(200.dp).background(PanelDark, RoundedCornerShape(16.dp)).padding(12.dp)) {
            CandleChart(candles)
        }

        Spacer(Modifier.height(14.dp))

        if (!awaitingReveal) {
            Text(if (language == "ur") "اگلی کینڈل کی سمت کا اندازہ لگائیں:" else "Guess the next candle's direction:", color = BrandSilverDim, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { pendingGuess = true; awaitingReveal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandGreen, contentColor = Color(0xFF04120B)),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f).height(50.dp)
                ) { Icon(Icons.Filled.TrendingUp, contentDescription = null); Spacer(Modifier.width(6.dp)); Text(if (language == "ur") "اوپر" else "Up") }

                Button(
                    onClick = { pendingGuess = false; awaitingReveal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed.copy(alpha = 0.15f), contentColor = BrandRed),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f).height(50.dp)
                ) { Icon(Icons.Filled.TrendingDown, contentDescription = null); Spacer(Modifier.width(6.dp)); Text(if (language == "ur") "نیچے" else "Down") }
            }
        } else {
            LaunchedEffect(pendingGuess) {
                val next = generateNextCandle(candles.last())
                val wasUp = next.isBullish
                val correct = (pendingGuess == wasUp)
                candles = (candles + next).takeLast(20)

                if (correct) { wins++; balance += tradeAmount } else { losses++; balance -= tradeAmount }
                lastExplanation = explainCandle(next, language)
                awaitingReveal = false
                pendingGuess = null

                if (balance <= 0f || balance >= targetBalance) {
                    kotlinx.coroutines.delay(1200)
                    gameState = GameState.FINISHED
                }
            }
            CircularProgressIndicator(color = BrandGreen, modifier = Modifier.size(28.dp))
        }

        lastExplanation?.let { explanation ->
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = PanelDark), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(explanation, color = BrandSilverDim, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }

        Spacer(Modifier.height(60.dp))
    }
}

@Composable
private fun SetupScreen(
    language: String,
    startingBalance: Float, onStartingBalanceChange: (Float) -> Unit,
    tradeAmount: Float, onTradeAmountChange: (Float) -> Unit,
    targetBalance: Float, onTargetBalanceChange: (Float) -> Unit,
    onStart: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().background(BgBlack).padding(20.dp)) {
        Text(if (language == "ur") "پریکٹس سیشن ترتیب دیں" else "Set Up Practice Session", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            if (language == "ur") "یہ سب ڈیمو رقم ہے — کوئی حقیقی پیسہ استعمال نہیں ہوتا" else "This is all virtual demo money — no real funds are used",
            color = BrandSilverDim, fontSize = 12.sp
        )

        Spacer(Modifier.height(24.dp))

        AmountSelector(
            label = if (language == "ur") "ابتدائی ڈیمو بیلنس" else "Starting Demo Balance",
            options = listOf(10f, 20f, 50f, 100f),
            selected = startingBalance,
            onSelect = onStartingBalanceChange
        )

        Spacer(Modifier.height(20.dp))

        AmountSelector(
            label = if (language == "ur") "فی ٹریڈ رقم" else "Amount Per Trade",
            options = listOf(5f, 10f, 20f, 25f),
            selected = tradeAmount,
            onSelect = onTradeAmountChange
        )

        Spacer(Modifier.height(20.dp))

        AmountSelector(
            label = if (language == "ur") "ہدف بیلنس" else "Target Balance",
            options = listOf(50f, 100f, 200f, 500f),
            selected = targetBalance,
            onSelect = onTargetBalanceChange
        )

        Spacer(Modifier.height(32.dp))

        Button(
            onClick = onStart,
            colors = ButtonDefaults.buttonColors(containerColor = BrandGreen, contentColor = Color(0xFF04120B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (language == "ur") "پریکٹس شروع کریں" else "Start Practice", fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth().background(PanelDark, RoundedCornerShape(12.dp)).padding(14.dp)) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = BrandSilverDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                if (language == "ur") "یہ ایک بے ترتیب تشبیہ ہے، تعلیمی مقصد کے لیے — حقیقی مارکیٹ سے مختلف ہو سکتی ہے۔"
                else "This is a randomized simulation for learning purposes — real markets can behave differently.",
                color = BrandSilverDim, fontSize = 10.sp, lineHeight = 14.sp
            )
        }
    }
}

@Composable
private fun AmountSelector(label: String, options: List<Float>, selected: Float, onSelect: (Float) -> Unit) {
    Text(label, color = BrandSilverDim, fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { amount ->
            val isSelected = amount == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) BrandGreen.copy(alpha = 0.15f) else PanelDark)
                    .clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        indication = null,
                        onClick = { onSelect(amount) }
                    )
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "$${amount.toInt()}",
                    color = if (isSelected) BrandGreen else BrandSilverDim,
                    fontSize = 13.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
private fun ResultScreen(language: String, won: Boolean, finalBalance: Float, wins: Int, losses: Int, onRestart: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(BgBlack).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            if (won) Icons.Filled.EmojiEvents else Icons.Filled.SentimentDissatisfied,
            contentDescription = null,
            tint = if (won) BrandGreen else BrandRed,
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            if (won) (if (language == "ur") "ہدف حاصل! 🎉" else "Target Reached! 🎉") else (if (language == "ur") "بیلنس ختم ہوگیا" else "Balance Depleted"),
            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text("Final: $${"%.2f".format(finalBalance)} · $wins wins · $losses losses", color = BrandSilverDim, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onRestart,
            colors = ButtonDefaults.buttonColors(containerColor = BrandGreen, contentColor = Color(0xFF04120B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(0.7f).height(50.dp)
        ) { Text(if (language == "ur") "دوبارہ کھیلیں" else "Play Again", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ScoreCard(modifier: Modifier, label: String, value: String, color: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelDark), shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(label, color = BrandSilverDim, fontSize = 10.sp)
        }
    }
}

@Composable
private fun CandleChart(candles: List<DemoCandle>) {
    val allValues = candles.flatMap { listOf(it.high, it.low) }
    val maxV = allValues.maxOrNull() ?: 1f
    val minV = allValues.minOrNull() ?: 0f
    val range = max(maxV - minV, 0.01f)

    Canvas(modifier = Modifier.fillMaxSize()) {
        val candleWidth = size.width / candles.size
        candles.forEachIndexed { i, c ->
            val xCenter = i * candleWidth + candleWidth / 2
            val color = if (c.isBullish) Color(0xFF34E39A) else Color(0xFFFF5C6A)
            fun yFor(v: Float) = size.height - ((v - minV) / range) * size.height

            drawLine(color = color, start = Offset(xCenter, yFor(c.high)), end = Offset(xCenter, yFor(c.low)), strokeWidth = 2f, cap = StrokeCap.Round)
            val bodyTop = yFor(max(c.open, c.close))
            val bodyBottom = yFor(min(c.open, c.close))
            drawRect(color = color, topLeft = Offset(xCenter - candleWidth * 0.3f, bodyTop), size = androidx.compose.ui.geometry.Size(candleWidth * 0.6f, max(bodyBottom - bodyTop, 2f)))
        }
    }
}

private fun generateInitialCandles(): List<DemoCandle> {
    var price = 100f
    val list = mutableListOf<DemoCandle>()
    repeat(15) {
        val open = price
        val close = open + Random.nextFloat() * 6f - 3f
        val high = max(open, close) + Random.nextFloat() * 2f
        val low = min(open, close) - Random.nextFloat() * 2f
        list.add(DemoCandle(open, close, high, low))
        price = close
    }
    return list
}

private fun generateNextCandle(last: DemoCandle): DemoCandle {
    val open = last.close
    val close = open + Random.nextFloat() * 6f - 3f
    val high = max(open, close) + Random.nextFloat() * 2f
    val low = min(open, close) - Random.nextFloat() * 2f
    return DemoCandle(open, close, high, low)
}

private fun explainCandle(c: DemoCandle, language: String): String {
    val wickTop = c.high - max(c.open, c.close)
    val wickBottom = min(c.open, c.close) - c.low
    val bigWick = wickTop > c.bodySize * 0.8f || wickBottom > c.bodySize * 0.8f

    return if (language == "ur") {
        when {
            c.isBullish && bigWick -> "یہ کینڈل سبز بنی کیونکہ قیمت آخر میں خریداری کے دباؤ سے اوپر بند ہوئی، لیکن لمبی بتی سے پتہ چلتا ہے کہ درمیان میں فروخت کا دباؤ بھی تھا۔"
            c.isBullish -> "یہ کینڈل سبز بنی کیونکہ بند ہونے کی قیمت کھلنے کی قیمت سے زیادہ رہی — خریداری کا دباؤ حاوی رہا۔"
            bigWick -> "یہ کینڈل سرخ بنی کیونکہ قیمت نیچے بند ہوئی، لمبی بتی دکھاتی ہے کہ قیمت میں کچھ اتار چڑھاؤ آیا۔"
            else -> "یہ کینڈل سرخ بنی کیونکہ بند ہونے کی قیمت کھلنے کی قیمت سے کم رہی — فروخت کا دباؤ حاوی رہا۔"
        }
    } else {
        when {
            c.isBullish && bigWick -> "This candle closed green — buying pressure won by the close, but the long wick shows sellers pushed back partway through."
            c.isBullish -> "This candle closed green because the close price ended higher than the open — buying pressure was dominant this round."
            bigWick -> "This candle closed red, and the long wick shows the price swung significantly before settling lower."
            else -> "This candle closed red because the close price ended lower than the open — selling pressure was dominant this round."
        }
    }
}
